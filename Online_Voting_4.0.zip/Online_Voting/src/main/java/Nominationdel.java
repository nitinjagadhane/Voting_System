import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.sql.*;
@WebServlet("/Nominationdel")
public class Nominationdel extends HttpServlet
   {
      public void init(ServletConfig config)throws ServletException
              {
                super.init(config);
              }
public void service(HttpServletRequest req, HttpServletResponse res)throws ServletException,IOException
 {
   ServletOutputStream sos = res.getOutputStream();
   try
     {
       
       int empid =Integer.parseInt( req.getParameter("empid" ));
       Class.forName("oracle.jdbc.driver.OracleDriver");
       Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","System");
       Statement st = con.createStatement();
       int k = st.executeUpdate("delete from Nomination where Empid= " +empid);
       System.out.println("no of rows deleted :" +k);
       sos.print("<html><body bgcolor=pink><h3>One record in Nomination Table is deleted from DataBase Successfully</h3></body></html>");
     }

   catch(Exception e)
    {
       System.out.println(e);
   }
}

}

 

 