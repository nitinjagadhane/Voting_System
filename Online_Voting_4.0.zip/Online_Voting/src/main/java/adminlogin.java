import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
@WebServlet("/adminlogin")
public class adminlogin extends HttpServlet
   {
      /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void init(ServletConfig config)throws ServletException
              {
                super.init(config);
              }
	protected void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException,IOException
 {
   
     String name =req.getParameter("username");
    			String name1 = "nitin";
    			String password = req.getParameter("password");
    			String password1 = "123";
    			
    			if(name.equals(name1) && password.equals(password1))
    			{
    				
    				res.sendRedirect("Home.html");
    			}
    			else{
    				
    				res.sendRedirect("voting.htm");
    			}
}

}

 

 