

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/VoterInsert")
public class VoterInsert extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public VoterInsert() {
        super();
         }

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		 try
	     {
	   
		   String Candidate_Name= req.getParameter("Candidate_Name"); 
	       String Party = req.getParameter("Party");
	       String Address = req.getParameter("Address");    

	       String Gender = req.getParameter("Gender");
	       String Assembly_Name = req.getParameter("Assembly_Name");
	  
	       String   contact =req.getParameter("contact");
	    
	       String Prefession = req.getParameter("Profession");
	       String Qualification = req.getParameter("Qualification");
	       String Sign = req.getParameter("Sign");
	       String Message = req.getParameter("Message");
	       String Nomi_Date = req.getParameter("Nomi_Date");
	       Class.forName("oracle.jdbc.driver.OracleDriver");
	       System.out.print("<html><body><h3>Electioncode  is inserted into DataBase Successfully</h3></body></html>");
	       Connection con =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","System");  
	       Statement st = con.createStatement();
	       System.out.print("<html><body><h3>Electioncode  is inserted into DataBase Successfully</h3></body></html>");
	       int k = st.executeUpdate("insert into Nomination_Data2  values('"+Candidate_Name+"', '"+Party+"' , '"+Address+"', '"+Gender+"', "
	       		+ "'"+Assembly_Name+"', '"+contact+"', '"+Prefession+"' , '"+Qualification+"', '"+Sign+"','"+Message+"', '"+Nomi_Date+"')");       System.out.println("no of rows inserted :" +k);
	     }

	   catch(Exception e)
	    {
	       System.out.println(e);
	   }
	}

}
