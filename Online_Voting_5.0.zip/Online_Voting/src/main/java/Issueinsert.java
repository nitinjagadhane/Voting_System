import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.sql.*;
@WebServlet("/Issueinsert")
public class Issueinsert extends HttpServlet
   {
      public void init(ServletConfig config)throws ServletException
              {
                super.init(config);
              }
public void service(HttpServletRequest req, HttpServletResponse res)throws ServletException,IOException
 {
      try
     {
       ServletOutputStream sos = res.getOutputStream();           
       int issueno = Integer.parseInt(req.getParameter("issueno"));
       String issue = req.getParameter("issue");
       String issuedate = req.getParameter("issuedate");
       String branch = req.getParameter("branch");
       Class.forName("oracle.jdbc.driver.OracleDriver");
       Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","System");
       Statement st = con.createStatement();
       int k = st.executeUpdate("insert into issue  values('"+issueno+"', '"+issue+"' , '"+issuedate+"' , '"+branch+"')");
       System.out.println("no of rows inserted :" +k);
       sos.print("<html><body><h3>Issue is inserted into DataBase Successfully</h3></body></html>");
       
     }

   catch(Exception e)
    {
       System.out.println(e);
   }
}

}

 

 