import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.sql.*;
@WebServlet("/Nomina")
public class Nomina extends HttpServlet
   {
      /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Nomina()
              {
                super();
              }
   
protected void doPost(HttpServletRequest req, HttpServletResponse res)throws ServletException,IOException
 {

      try
     {
   
    	  String Candidate_Name= req.getParameter("CandidateName"); 
       String Party = req.getParameter("Party");
       String Address = req.getParameter("Address");    

       String Gender = req.getParameter("Gender");
       String Assembly_Name = req.getParameter("Assembly_Name");
  
       String   contact =req.getParameter("contact");
    
       String Prefession = req.getParameter("Profession");
       String Qualification = req.getParameter("Qualification");
       String Sign = req.getParameter("Sign");
       String Message = req.getParameter("Message");
       String Nomi_Date = req.getParameter("Nomi_Date");
       System.out.printf(Prefession);
       Class.forName("oracle.jdbc.driver.OracleDriver");
       System.out.print("<html><body><h3>Electioncode  is inserted into DataBase Successfully</h3></body></html>");
       Connection con =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","System");  
       Statement st = con.createStatement();
       Statement st1=con.createStatement();
       ResultSet rs=st1.executeQuery("select * from Nomination");
      
       int Nominee_ID=0;
       
       while(rs.next()){
    	   Nominee_ID= rs.getInt(1);
    	}
       Nominee_ID++;
       
       System.out.print("<html><body><h3>Electioncode  is inserted into DataBase Successfully</h3></body></html>");
       int k = st.executeUpdate("insert into Nomination  values('"+Nominee_ID+"','"+Candidate_Name+"', '"+Party+"' , '"+Address+"', '"+Gender+"', "
       		+ "'"+Assembly_Name+"', '"+contact+"', '"+Prefession+"' , '"+Qualification+"', '"+Sign+"','"+Message+"', '"+Nomi_Date+"')");      
       System.out.println("no of rows inserted :" +k);
       res.sendRedirect("nomination.htm");
     
     
     }

   catch(Exception e)
    {
       System.out.println(e);
}
}
}

 

 