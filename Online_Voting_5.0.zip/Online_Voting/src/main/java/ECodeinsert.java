import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.sql.*;
@WebServlet("/ECodeinsert")
public class ECodeinsert extends HttpServlet
   {
      public void init(ServletConfig config)throws ServletException
              {
                super.init(config);
              }
public void service(HttpServletRequest req, HttpServletResponse res)throws ServletException,IOException
 {
     try
     {
       ServletOutputStream sos = res.getOutputStream();  
       String empid = req.getParameter("empid");
       String electioncode = req.getParameter("electioncode");
    
       Class.forName("oracle.jdbc.driver.OracleDriver");
       Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","System");
       Statement st = con.createStatement();
       int k = st.executeUpdate("insert into ecode  values('"+empid+"', '"+electioncode+"')");
       System.out.println("no of rows inserted :" +k);
        sos.print("<html><body><h3>Electioncode  is inserted into DataBase Successfully</h3></body></html>");
     }

   catch(Exception e)
    {
       System.out.println(e);
   }
}

}

 

 