import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.sql.*;
@WebServlet("/Complaintinsert")
public class Complaintinsert extends HttpServlet
   {
      /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void init(ServletConfig config)throws ServletException
              {
                super.init(config);
              }
public void service(HttpServletRequest req, HttpServletResponse res)throws ServletException,IOException
 {
    try
     {
       ServletOutputStream sos = res.getOutputStream();    
       int comp_no = Integer.parseInt(req.getParameter("comp_no"));   
       String complaint = req.getParameter("complaint");
       String comp_date = req.getParameter("comp_date");
       String branch = req.getParameter("branch");
       String category = req.getParameter("category");
       Class.forName("oracle.jdbc.driver.OracleDriver");
       Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","System");
       Statement st = con.createStatement();
       int k = st.executeUpdate("insert into comp values('"+comp_no+"', '"+complaint+"' , '"+comp_date+"' , '"+branch+"','"+category+"')");       System.out.println("no of rows inserted :" +k);
       sos.print("<html><body><h3>complaint is inserted into DataBase Successfully</h3></body></html>");
     }


   catch(Exception e)
    {
       System.out.println(e);
   }
}

}

 

 