

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/VoterInsert")
public class VoterInsert extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public VoterInsert() {
        super();
         }

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		 try
	     {
	   
		String Name= req.getParameter("Name"); 
	       String Address = req.getParameter("Address");
	       String Contact = req.getParameter("Contact");    

	       String Aadhar = req.getParameter("Aadhar");
	       String DOB= req.getParameter("DOB"); 
	       String Gender= req.getParameter("Gender"); 
	       String Qualification= req.getParameter("Qualification"); 
	      
	       
	  
	     
	       Class.forName("oracle.jdbc.driver.OracleDriver");
	       
	       Connection con =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","System");  
	       Statement st = con.createStatement();
	     
	       int k = st.executeUpdate("insert into Voter_Info values('"+Name+"', '"+Address+"' , '"+Contact+"','"+Aadhar+"','"+DOB+"','"+Gender+"','"+Qualification+"')"); 
	       														
	       System.out.println("no of rows inserted :" +k);
	       res.setContentType("text/html"); 
	       PrintWriter out = res.getWriter(); 
	       out.println("<script type=\"text/javascript\">"); 
	       out.println("alert('Voter Inserted successfully');"); 
	       out.println("location='Voter_Reg.htm';"); 
	       out.println("</script>"); 
	     }

	   catch(Exception e)
	    {
	       System.out.println(e);
	   }
	}

}
